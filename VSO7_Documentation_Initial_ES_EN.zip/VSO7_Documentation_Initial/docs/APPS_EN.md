# VSO7 application removal guide

This guide covers the **140 applications** in VSO7’s app selector. “Safe” does not mean “garbage”: it means basic Windows operation does not require it. **If you use it, keep it.**

> **App removal does not have the same automatic Recovery as a reversible tweak.** Many apps can be installed again from Microsoft Store or another installer, but VSO7 does not promise to rebuild the exact previous state.

- **Safe (86):** non-essential to basic Windows. VSO7 may select it by default.
- **Optional (48):** can be useful or tied to other features; you decide.
- **Not recommended (6):** other Windows/app features may depend on it.

## Safe / non-essential

### Clipchamp

- **What it is:** Microsoft video editor.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### 3D Builder

- **What it is:** older 3D model/printing tool.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Cortana

- **What it is:** Microsoft’s old assistant.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Finance

- **What it is:** financial news and data.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Food And Drink

- **What it is:** recipes and food content.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Health And Fitness

- **What it is:** health and fitness content.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing News

- **What it is:** news.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Sports

- **What it is:** sports news and results.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Translator

- **What it is:** translation.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Travel

- **What it is:** travel information.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bing Weather

- **What it is:** weather forecasts.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft Copilot

- **What it is:** the Copilot app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Copilot+ AI Hub

- **What it is:** AI features hub for supported PCs.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft PC Manager

- **What it is:** Microsoft maintenance tools.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Get Started

- **What it is:** Windows tips and welcome content.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Messaging

- **What it is:** the old messaging app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### 3D Viewer

- **What it is:** 3D model viewer.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft Journal

- **What it is:** handwritten notes.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Office Hub

- **What it is:** Microsoft 365 shortcuts and promotion.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Power BI

- **What it is:** Power BI report viewer.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Solitaire Collection

- **What it is:** Microsoft card games.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Sticky Notes

- **What it is:** Sticky Notes.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Mixed Reality Portal

- **What it is:** Mixed Reality portal.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Network Speed Test

- **What it is:** network speed test.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft News

- **What it is:** Microsoft news.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### OneNote

- **What it is:** OneNote notes.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Sway

- **What it is:** Sway presentations/pages.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### One Connect

- **What it is:** older Microsoft connectivity app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Print 3D

- **What it is:** 3D printing.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Power Automate

- **What it is:** task automation.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Skype (UWP)

- **What it is:** older Skype app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft To Do

- **What it is:** lists and tasks.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Dev Home

- **What it is:** developer dashboard.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Alarms & Clock

- **What it is:** alarms, clocks and timers.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Feedback Hub

- **What it is:** sending feedback to Microsoft.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Windows Maps

- **What it is:** maps.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Sound Recorder

- **What it is:** audio recording.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Xbox Console Companion

- **What it is:** old Xbox companion app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Movies & TV

- **What it is:** Microsoft video player.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Family Safety

- **What it is:** family controls.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Quick Assist

- **What it is:** remote assistance.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft Teams (Old)

- **What it is:** old Teams app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Microsoft Teams (New)

- **What it is:** Teams app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### ACG Media Player

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Actipro Software

- **What it is:** third-party Actipro package.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Adobe Photoshop Express

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Amazon

- **What it is:** Amazon shopping app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Prime Video

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Asphalt 8

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Autodesk SketchBook

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Caesars Slots

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Cooking Fever

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### CyberLink Media Suite

- **What it is:** CyberLink media utilities.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Disney Magic Kingdoms

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Disney+

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Drawboard PDF

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Duolingo

- **What it is:** language learning.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Eclipse Manager

- **What it is:** third-party app called Eclipse Manager.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Facebook

- **What it is:** third-party social/content app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### FarmVille 2

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Flipboard

- **What it is:** third-party social/content app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Hidden City

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Hulu

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### iHeartRadio

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Instagram

- **What it is:** third-party social/content app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Bubble Witch 3

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Candy Crush Saga

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Candy Crush Soda

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### LinkedIn

- **What it is:** third-party social/content app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### March of Empires

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Netflix

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### NYT Crossword

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### One Calendar

- **What it is:** third-party calendar.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Pandora

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Phototastic Collage

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### PicsArt

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Polarr Photo Editor

- **What it is:** the “Polarr Photo Editor” app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Royal Revolt

- **What it is:** third-party game/entertainment app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Live Wallpaper

- **What it is:** third-party creative/editing app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Sling TV

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### Spotify

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### TikTok

- **What it is:** third-party social/content app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### TuneIn Radio

- **What it is:** media playback/streaming app.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### WinZip

- **What it is:** file compression/archive utility.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** Yes.

### People

- **What it is:** contacts.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** No.

### Mail & Calendar

- **What it is:** old mail/calendar apps.
- **Would I remove it?:** Yes, if you do not use it. Basic Windows operation does not require it.
- **Risk:** Low: you mainly lose that app and its features.
- **Selected by VSO7 by default:** No.

## Optional: your choice

### Bing Search

- **What it is:** Bing web results integrated into Windows.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Xbox Gaming App

- **What it is:** Xbox and PC Game Pass.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose the Xbox app and convenient PC Game Pass access.

### Microsoft 365 Companions

- **What it is:** small apps tied to Microsoft 365.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Paint 3D

- **What it is:** Microsoft 3D editor.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### OneDrive

- **What it is:** OneDrive file sync.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** Check whether Desktop, Documents or Pictures are synced first: synchronization will stop.

### Outlook for Windows

- **What it is:** Outlook mail/calendar.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Paint

- **What it is:** basic image/drawing editor.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You will need another basic drawing/editing app.

### Remote Desktop

- **What it is:** Remote Desktop client.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose that remote connection client.

### Snipping Tool

- **What it is:** screenshots and screen recording.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose the built-in screenshot and screen-recording tool.

### Widgets Experience

- **What it is:** Windows Widgets experience.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Whiteboard

- **What it is:** collaborative whiteboard.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Photos

- **What it is:** photo viewer/editor.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You will need another image viewer.

### Calculator

- **What it is:** calculator.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You will need another calculator.

### Camera

- **What it is:** camera/webcam app.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose the built-in Camera app.

### Notepad

- **What it is:** simple text editor.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You will need another text editor.

### Xbox Game Overlay

- **What it is:** part of the Xbox in-game overlay.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You may lose parts of Game Bar.

### Xbox Gaming Overlay

- **What it is:** Xbox Game Bar.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You may lose Game Bar, captures and Xbox widgets.

### Phone Link

- **What it is:** PC-to-phone integration.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose phone integration.

### Media Player

- **What it is:** media player.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You will need another media player.

### Cross Device Experience

- **What it is:** cross-device features.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Windows Web Experience Pack

- **What it is:** web components used by Widgets and other Windows surfaces.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** This can affect Widgets and other Windows surfaces.

### Widgets Platform Runtime

- **What it is:** runtime needed by Widgets.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** Widgets may stop working.

### LG Monitor App

- **What it is:** LG monitor utilities.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP AI Experience Center

- **What it is:** HP AI features.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Connected Music

- **What it is:** old HP media app.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Connected Photo

- **What it is:** old HP photo app.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Desktop Support Utilities

- **What it is:** HP support utilities.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Easy Clean

- **What it is:** temporary input lock for cleaning the PC.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP File Viewer

- **What it is:** HP file viewer.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP JumpStarts

- **What it is:** HP welcome/promotional app.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP PC Hardware Diagnostics

- **What it is:** HP hardware diagnostics.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Power Manager

- **What it is:** HP battery/power controls.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You may lose HP-specific battery/charging controls.

### HP Printer Control

- **What it is:** HP printer controls.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** If you use an HP printer, you may lose controls from this app.

### HP Privacy Settings

- **What it is:** HP privacy settings.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP QuickDrop

- **What it is:** HP quick file transfer.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP QuickTouch

- **What it is:** quick features on some HP PCs.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Registration

- **What it is:** HP device registration.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Support Assistant

- **What it is:** HP support, diagnostics and updates.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose HP’s support/update workflow; Windows Update still works.

### HP Sure Shield AI

- **What it is:** supported HP security features.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP System Information

- **What it is:** HP system information.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP Welcome

- **What it is:** HP welcome screen.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### HP WorkWell

- **What it is:** HP wellbeing tools.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### myHP

- **What it is:** HP features/support dashboard.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Lenovo Vantage

- **What it is:** Lenovo settings, battery, firmware and support.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You may lose Lenovo battery, charging, thermal-mode or update controls.

### Lenovo Vantage Service

- **What it is:** service required by several Lenovo Vantage features.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** Lenovo Vantage may stop working correctly.

### Dell SupportAssist

- **What it is:** Dell support, diagnostics and updates.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose Dell’s support/diagnostic/update workflow; Windows Update still works.

### Dell Digital Delivery Services

- **What it is:** delivery of software bundled/purchased with Dell.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

### Dell Mobile Connect

- **What it is:** Dell phone-to-PC integration.
- **Would I remove it?:** Only if you know you do not need it. VSO7 does not select it automatically.
- **Risk:** Medium: you may lose a Windows/OEM feature you actually use.
- **Selected by VSO7 by default:** No.

## Not recommended for removal

### Get Help

- **What it is:** Windows help/support.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** You lose the built-in support app.

### Microsoft Store

- **What it is:** app store and app updating.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** This can make installing and updating Microsoft apps much less convenient.

### Windows Terminal

- **What it is:** modern Windows terminal.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** You may lose the modern terminal used by PowerShell, CMD and development tools.

### Xbox TCUI Framework

- **What it is:** Xbox sign-in/interface components used by games.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** Some games may lose Xbox dialogs or features.

### Xbox Identity Provider

- **What it is:** Xbox sign-in and identity.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** This can break Xbox sign-in, Game Pass and games that use Xbox identity.

### Xbox Speech To Text

- **What it is:** Xbox voice/text features.
- **Would I remove it?:** I would not remove it unless you know exactly what depends on it.
- **Risk:** High: removing it can break other apps or Windows features.
- **Selected by VSO7 by default:** No.
- **Watch out:** This can break Xbox voice/accessibility features.
