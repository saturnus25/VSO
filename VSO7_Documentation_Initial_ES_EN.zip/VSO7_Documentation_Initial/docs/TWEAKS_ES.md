# Guía de tweaks de VSO7


Esta documentación cubre los **120 tweaks seleccionables** del catálogo actual de VSO7. Los diagnósticos de solo lectura no están mezclados aquí porque no son optimizaciones.

La idea es sencilla: **“funciona” no significa “da más FPS”**. Hay opciones que arreglan una configuración claramente mala, otras que solo cambian cómo se comporta Windows y otras que existen para hacer pruebas A/B.

### Leyenda rápida

- **Riesgo 1/4:** cambio pequeño.
- **Riesgo 2/4:** puede afectar consumo, compatibilidad o alguna función.
- **Riesgo 3/4:** puede desactivar algo importante o reducir protección.
- **Riesgo 4/4:** operación agresiva/difícil de recuperar.
- **Recomendado:** VSO7 solo lo propone automáticamente cuando detecta que encaja.
- **Opcional:** funciona, pero depende de tus preferencias.
- **Avanzado:** caso concreto; no es una mejora universal.
- **Experimental:** solo para comparar antes/después.

**Resumen del catálogo:** 9 recomendados, 74 opcionales, 28 avanzados y 9 experimentales.

## Índice

1. [Especiales](#cat-especiales)
2. [Privacidad y contenido sugerido](#cat-privacidad-y-contenido-sugerido)
3. [Inteligencia artificial](#cat-inteligencia-artificial)
4. [Gaming](#cat-gaming)
5. [Inicio y busqueda](#cat-inicio-y-busqueda)
6. [Otros](#cat-otros)
7. [Apariencia](#cat-apariencia)
8. [Sistema](#cat-sistema)
9. [Multitarea](#cat-multitarea)
10. [Barra de tareas](#cat-barra-de-tareas)
11. [Explorador de archivos](#cat-explorador-de-archivos)
12. [Windows Update](#cat-windows-update)
13. [Funciones opcionales de Windows](#cat-funciones-opcionales-de-windows)
14. [Energía y USB](#cat-energia-y-usb)
15. [Red](#cat-red)
16. [Diagnóstico](#cat-diagnostico)
17. [CPU y energia](#cat-cpu-y-energia)
18. [Almacenamiento](#cat-almacenamiento)
19. [Graficos y GPU](#cat-graficos-y-gpu)

<a id="cat-especiales"></a>
## Especiales

### Eliminar apps de Xbox y Barra de juegos

- **Qué hace:** Desinstala la app Xbox y componentes de Barra de juegos. No conviene si usas Game Pass, capturas Xbox o funciones sociales de Xbox.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección. Perderás componentes de Xbox/Game Bar. Puede afectar Game Pass, capturas, inicio de sesión Xbox o funciones sociales.
- **¿Se puede revertir?:** No con el Recovery normal de VSO7. Si lo aplicas, asume que quizá tengas que repararlo o reinstalarlo manualmente.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Eliminar software OEM de HP

- **Qué hace:** Desinstala varias aplicaciones HP preinstaladas. Puede quitar utilidades de soporte o funciones especificas del fabricante.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección. Puedes perder utilidades de batería, soporte, diagnóstico, impresora u otras funciones propias de HP.
- **¿Se puede revertir?:** No con el Recovery normal de VSO7. Si lo aplicas, asume que quizá tengas que repararlo o reinstalarlo manualmente.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Forzar desinstalacion de Microsoft Edge

- **Qué hace:** Intenta quitar Edge incluso en configuraciones donde Windows lo trata como componente. Puede romper enlaces, widgets o funciones que dependen de WebView/Edge.
- **¿Funciona / merece la pena?:** Puede quitar Edge, pero VSO7 lo considera una operación agresiva: otras partes de Windows pueden depender de componentes de Edge.
- **Peligrosidad:** **Muy alto (4/4)** — Muy alto: puede quitar un componente importante y ser difícil de recuperar. Puede romper enlaces, Widgets o funciones que usan componentes web de Microsoft. Recuperarlo puede requerir reinstalación manual.
- **¿Se puede revertir?:** No con el Recovery normal de VSO7. Si lo aplicas, asume que quizá tengas que repararlo o reinstalarlo manualmente.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-privacidad-y-contenido-sugerido"></a>
## Privacidad y contenido sugerido

### Reducir telemetria y anuncios dirigidos

- **Qué hace:** Desactiva varias opciones de diagnostico, seguimiento y personalizacion publicitaria de Windows sin desactivar Windows Update.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar consejos y contenido sugerido

- **Qué hace:** Quita recomendaciones, consejos y sugerencias promocionales que Windows muestra en distintas partes de la interfaz.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar notificaciones de aplicaciones

- **Qué hace:** Desactiva las notificaciones de aplicaciones y otros remitentes. Puedes perder avisos utiles.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar servicios de ubicacion

- **Qué hace:** Impide que Windows y las aplicaciones usen la ubicacion del dispositivo hasta que lo vuelvas a activar.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta. Las aplicaciones dejarán de obtener la ubicación hasta que lo reviertas.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar Buscar mi dispositivo

- **Qué hace:** Desactiva el seguimiento usado por Buscar mi dispositivo; perderas esa funcion antirrobo/localizacion.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta. Pierdes “Buscar mi dispositivo”.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Quitar consejos de la pantalla de bloqueo

- **Qué hace:** Elimina sugerencias y contenido promocional de la pantalla de bloqueo.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Quitar anuncios y sugerencias de Edge

- **Qué hace:** Reduce noticias, recomendaciones y contenido promocional dentro de Microsoft Edge.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar promociones de Microsoft 365 en Configuracion

- **Qué hace:** Quita banners y promociones de Microsoft 365/Copilot de la pagina principal de Configuracion.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-inteligencia-artificial"></a>
## Inteligencia artificial

### Desactivar Microsoft Copilot

- **Qué hace:** Desactiva la integracion de Copilot en Windows. No desinstala aplicaciones de terceros.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar Windows Recall

- **Qué hace:** Desactiva Recall para evitar que Windows use esa funcion de historial/capturas asistidas por IA.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar Click to Do

- **Qué hace:** Desactiva el analisis contextual de texto e imagenes de Click to Do.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Evitar inicio automatico del servicio de IA

- **Qué hace:** Impide que el servicio de IA configurado por Windows se inicie automaticamente; algunas funciones de IA pueden dejar de funcionar.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar funciones de IA de Edge

- **Qué hace:** Desactiva varias funciones de IA integradas en Microsoft Edge.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar funciones de IA de Paint

- **Qué hace:** Desactiva funciones de IA de Paint cuando Windows las expone mediante estas politicas.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar funciones de IA del Bloc de notas

- **Qué hace:** Desactiva funciones de IA del Bloc de notas cuando estan disponibles.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-gaming"></a>
## Gaming

### Desactivar captura/grabacion de juegos (legacy)

- **Qué hace:** Desactiva captura/grabacion de juegos. VSO7 conserva esta variante avanzada por compatibilidad funcional, pero recomienda la variante por usuario porque esta tambien escribe una regla de Windows de equipo.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio. Pierdes captura/grabación de Xbox Game Bar mientras esté aplicado.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar control de grabacion al usuario

- **Qué hace:** Quita una prohibición forzada de grabación de juegos y devuelve el control al usuario. No activa las capturas por sí solo.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar capturas de juego por usuario

- **Qué hace:** Desactiva la grabación de juego en segundo plano para tu usuario. Reduce actividad de captura, pero pierdes la función de guardar lo que acaba de pasar de Xbox Game Bar.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio. Pierdes la captura automática en segundo plano de Xbox Game Bar.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Activar Game Mode

- **Qué hace:** Activa la preferencia oficial de Game Mode. No promete mas FPS; Windows decide la optimizacion efectiva segun juego, hardware y scheduler.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Recomendado**.

### Desactivar Game Mode para prueba A/B

- **Qué hace:** Desactiva Game Mode de forma reversible para comparar un juego concreto. No es una recomendacion universal.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.

### Permitir abrir Game Bar con mando

- **Qué hace:** Activa la preferencia oficial que permite abrir Game Bar con el boton del mando. Es una preferencia de UX, no un ajuste de rendimiento.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Bloquear apertura de Game Bar con mando

- **Qué hace:** Desactiva de forma reversible la apertura de Game Bar mediante el boton del mando. Solo cambia comportamiento de entrada/UX.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-inicio-y-busqueda"></a>
## Inicio y busqueda

### Ocultar Recomendados en Inicio

- **Qué hace:** Oculta la seccion de archivos y aplicaciones recomendadas del menu Inicio.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Todas las aplicaciones en Inicio

- **Qué hace:** Oculta la seccion/lista de todas las aplicaciones del menu Inicio.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Quitar Enlace Movil de Inicio

- **Qué hace:** Desactiva la integracion de Phone Link/Enlace Movil en el menu Inicio.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar resultados web de Bing en Busqueda

- **Qué hace:** Hace que la busqueda de Inicio se centre en resultados locales en vez de consultar Bing/Copilot.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar historial de busqueda de Windows

- **Qué hace:** Evita que la busqueda de Windows conserve el historial de busquedas del dispositivo. No desactiva Windows Search ni borra tus archivos.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar contenido destacado de Busqueda

- **Qué hace:** Quita el contenido dinamico o promocional que aparece en el cuadro de busqueda de Windows sin desactivar la busqueda.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-otros"></a>
## Otros

### Ocultar Inicio de Configuracion

- **Qué hace:** Hace que Configuracion no use la pagina Home/Inicio promocional como entrada principal.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar extras de Brave

- **Qué hace:** Desactiva varias funciones promocionales de Brave, como componentes de IA/cripto, segun la version instalada.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-apariencia"></a>
## Apariencia

### Activar modo oscuro

- **Qué hace:** Activa el tema oscuro para Windows y aplicaciones compatibles.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar transparencias

- **Qué hace:** Reduce efectos translucidos de Windows. Es un cambio visual reversible.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Reducir animaciones y efectos visuales

- **Qué hace:** Desactiva varias animaciones para que la interfaz se sienta mas inmediata.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio. La interfaz se verá menos animada y más simple.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-sistema"></a>
## Sistema

### Desactivar bandeja al arrastrar archivos

- **Qué hace:** Desactiva la bandeja que aparece al arrastrar archivos para compartir o moverlos.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Usar menu contextual clasico

- **Qué hace:** Usa el estilo clasico de menu contextual similar a Windows 10. Es principalmente un cambio de interfaz.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar Mejorar precision del puntero

- **Qué hace:** Desactiva la aceleracion del puntero de Windows para la ruta de puntero tradicional. Es una preferencia de control; juegos con raw input pueden ignorarla.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar atajo de Teclas especiales

- **Qué hace:** Evita que pulsar Shift cinco veces abra el dialogo de Teclas especiales; no desactiva el teclado.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar Sensor de almacenamiento

- **Qué hace:** Desactiva Storage Sense para el usuario actual. Es una preferencia de limpieza/espacio, no una optimizacion de FPS.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar Inicio rapido

- **Qué hace:** Hace que Apagar realice un apagado mas completo en vez de usar hibernacion parcial. El arranque puede tardar algo mas.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Evitar cifrado automatico futuro de BitLocker

- **Qué hace:** Evita que Windows active automaticamente el cifrado del dispositivo en ciertos equipos. No descifra unidades ya cifradas.
- **¿Funciona / merece la pena?:** Sí funciona, pero no es una optimización de rendimiento. Evita cifrado automático futuro y por tanto reduce protección si el equipo se pierde o es robado.
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección. Reduce seguridad frente a pérdida o robo porque evita que Windows active automáticamente cifrado en ciertos equipos. Reduce una protección de seguridad de Windows.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar red durante Modern Standby

- **Qué hace:** Reduce actividad de red mientras el equipo esta en Modern Standby; puede retrasar sincronizaciones en reposo.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta. Sin red durante Modern Standby, algunas sincronizaciones/notificaciones pueden esperar hasta que despiertes el PC.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-multitarea"></a>
## Multitarea

### Desactivar ajuste de ventanas

- **Qué hace:** Desactiva la funcion de acoplar ventanas a bordes y zonas de la pantalla.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar sugerencias al acoplar ventanas

- **Qué hace:** Mantiene otras funciones de ventanas pero evita que Windows sugiera aplicaciones para completar un diseño.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar diseños de acoplamiento

- **Qué hace:** Oculta el panel de diseños que aparece al pasar por maximizar o en la parte superior.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-barra-de-tareas"></a>
## Barra de tareas

### Alinear barra de tareas a la izquierda

- **Qué hace:** Mueve los iconos principales de la barra de tareas a la izquierda.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Vista de tareas

- **Qué hace:** Oculta el boton Vista de tareas; Win+Tab sigue dependiendo de la configuracion de Windows.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar Widgets

- **Qué hace:** Desactiva widgets de la barra y pantalla de bloqueo eliminando sus paquetes relacionados. Puede requerir reinstalarlos para recuperarlos.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección.
- **¿Se puede revertir?:** No con el Recovery normal de VSO7. Si lo aplicas, asume que quizá tengas que repararlo o reinstalarlo manualmente.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Chat/Reunirse ahora

- **Qué hace:** Oculta el acceso de Chat/Reunirse ahora de la barra de tareas.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Mostrar Finalizar tarea en la barra

- **Qué hace:** Añade una opcion para finalizar una aplicacion desde el menu contextual de su icono en la barra.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Activar ultimo clic activo en la barra

- **Qué hace:** Al pulsar un grupo de ventanas en la barra, cambia directamente a la ultima ventana activa.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-explorador-de-archivos"></a>
## Explorador de archivos

### Mostrar extensiones de archivo

- **Qué hace:** Muestra .exe, .txt, .jpg y otras extensiones conocidas; ayuda a identificar mejor los archivos.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Mostrar archivos y carpetas ocultos

- **Qué hace:** Hace visibles elementos marcados como ocultos en el Explorador.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar unidades extraibles duplicadas

- **Qué hace:** Evita que ciertas unidades USB aparezcan duplicadas en el panel de navegacion.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Inicio del Explorador

- **Qué hace:** Quita Inicio/Home del panel de navegacion del Explorador.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Galeria del Explorador

- **Qué hace:** Quita Galeria del panel de navegacion.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar OneDrive del Explorador

- **Qué hace:** Oculta OneDrive del panel de navegacion; no desinstala el cliente ni borra archivos.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar carpeta Objetos 3D

- **Qué hace:** Quita la carpeta Objetos 3D de Este equipo.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar carpeta Musica

- **Qué hace:** Quita Musica de Este equipo/panel segun la version de Windows.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Añadir carpetas comunes a Este equipo

- **Qué hace:** Vuelve a mostrar carpetas comunes como Documentos/Descargas en Este equipo.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Incluir en biblioteca

- **Qué hace:** Quita esa entrada del menu contextual del Explorador.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Dar acceso a

- **Qué hace:** Quita la entrada de compartir mediante "Dar acceso a" del menu contextual.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Ocultar Compartir

- **Qué hace:** Quita la entrada Compartir del menu contextual moderno.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-windows-update"></a>
## Windows Update

### No recibir actualizaciones en cuanto esten disponibles

- **Qué hace:** Desactiva la opcion de adelantarse a actualizaciones no urgentes; Windows Update sigue funcionando.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Evitar reinicios automaticos de Update con sesion iniciada

- **Qué hace:** Reduce reinicios automaticos por actualizaciones mientras hay un usuario conectado.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta. Puede retrasar reinicios que Windows Update quería hacer automáticamente.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar compartir actualizaciones con otros PCs

- **Qué hace:** Evita que Delivery Optimization intercambie partes de actualizaciones con otros equipos.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Evitar apps compañeras automaticas de dispositivos

- **Qué hace:** Impide que Windows instale automaticamente ciertas aplicaciones recomendadas al conectar hardware.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-funciones-opcionales-de-windows"></a>
## Funciones opcionales de Windows

### Activar Windows Sandbox

- **Qué hace:** Habilita la caracteristica opcional Sandbox. Puede requerir reinicio y virtualizacion compatible.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección. Añade una función de virtualización de Windows y puede requerir reinicio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Activar WSL

- **Qué hace:** Habilita WSL y Virtual Machine Platform. Puede requerir reinicio y cambia las caracteristicas opcionales instaladas.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección. Añade WSL y componentes de virtualización. Puede requerir reinicio y cambia funciones instaladas.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-energia-y-usb"></a>
## Energía y USB

### Restaurar suspensión selectiva USB

- **Qué hace:** Devuelve a Windows la capacidad de poner en reposo dispositivos USB que no se están usando. Ahorra energía; no es un tweak para ganar FPS.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

<a id="cat-red"></a>
## Red

### Activar RSS en NIC física compatible

- **Qué hace:** Permite que el trabajo de recibir datos de red se reparta entre varios núcleos del procesador. Puede ayudar con mucho tráfico; no promete bajar el ping.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar checksum offloads de NIC física

- **Qué hace:** Permite que la tarjeta de red haga parte del trabajo de comprobar los datos que entran y salen, en vez de cargar todo sobre la CPU.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Recomendado**.

### Restaurar Large Send Offload (LSO)

- **Qué hace:** Permite que la tarjeta de red prepare envíos grandes con menos trabajo para la CPU. Suele ayudar a eficiencia de red; no es un tweak de ping.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar RSC en NIC física

- **Qué hace:** Permite agrupar parte del tráfico recibido para reducir trabajo de CPU. Favorece eficiencia y velocidad sostenida, no necesariamente latencia.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar RSC para prueba de baja latencia

- **Qué hace:** Deja de agrupar tráfico recibido para probar si tu caso concreto mejora algo de latencia. Puede aumentar el uso de CPU; está pensado para comparar antes/después.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar RSS global del stack TCP/IP

- **Qué hace:** Vuelve a permitir que Windows reparta el trabajo de red entrante entre varios núcleos. Es una restauración sensata si alguien lo había desactivado.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### Restaurar RSC global del stack TCP/IP

- **Qué hace:** Vuelve a permitir que Windows agrupe tráfico recibido para reducir trabajo de CPU. No es una mejora universal de ping.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar task offload global

- **Qué hace:** Vuelve a permitir que Windows use funciones de ayuda de la tarjeta de red en vez de hacerlo todo con la CPU.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Restaurar TCP receive autotuning Normal

- **Qué hace:** Devuelve a Windows el control automático del tamaño de recepción de red. Evita límites manuales que pueden reducir la velocidad de descarga o transferencia.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### Activar moderación de interrupciones

- **Qué hace:** Hace que la tarjeta de red agrupe avisos a la CPU. Reduce carga de procesador, pero puede añadir una cantidad pequeña de latencia.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar moderación para prueba de baja latencia

- **Qué hace:** Hace que la tarjeta de red avise a la CPU con menos agrupación para probar menor latencia. Puede aumentar bastante el trabajo de CPU.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar Energy Efficient Ethernet

- **Qué hace:** Vuelve a activar el ahorro de energía de Ethernet cuando la tarjeta lo soporta. Ahorra energía; no es una mejora de gaming.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Activar Wake-on-Magic-Packet compatible

- **Qué hace:** Permite encender o despertar el PC desde la red con una señal especial cuando la tarjeta lo soporta. No mejora el rendimiento.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Restaurar selective suspend de NIC en laptop

- **Qué hace:** Vuelve a permitir que un portátil duerma una tarjeta de red inactiva para ahorrar batería. No mejora el ping.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Restaurar ECN a Disabled

- **Qué hace:** Devuelve una función especial de congestión de red a su estado normal desactivado. Es una normalización, no un tweak de velocidad.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Activar ECN para prueba A/B

- **Qué hace:** Activa una función especial de congestión de red para probarla en una red compatible. No se recomienda como mejora general.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Experimental**.

### Restaurar TCP timestamps a Allowed

- **Qué hace:** Devuelve las marcas de tiempo de red al comportamiento normal de Windows. No promete menor ping.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Activar Wake-on-Pattern compatible

- **Qué hace:** Permite que ciertos patrones de tráfico despierten el PC. Es comodidad/energía, no rendimiento.
- **¿Funciona / merece la pena?:** Sí, hace exactamente ese cambio, pero es una preferencia de uso o aspecto; **no es una promesa de más rendimiento**.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Forzar TCP timestamps para prueba A/B

- **Qué hace:** Fuerza unas marcas de tiempo de red solo para comparar resultados. No es una optimización general.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Experimental**.

### Desactivar TCP timestamps para prueba A/B

- **Qué hace:** Desactiva unas marcas de tiempo de red solo para comparar resultados. No es una optimización general.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Experimental**.

### Desactivar Energy Efficient Ethernet para prueba A/B

- **Qué hace:** Desactiva el ahorro de energía de Ethernet para probar si cambia la latencia o estabilidad. Puede aumentar consumo y no garantiza menor ping.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.

### Desactivar Large Send Offload para prueba A/B

- **Qué hace:** Hace que la CPU se encargue de más trabajo al enviar datos de red para comparar resultados. Puede aumentar uso de CPU y no garantiza menor latencia.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.

### Desactivar checksum offloads para prueba A/B

- **Qué hace:** Hace que la CPU se encargue también de comprobar paquetes de red para comparar resultados. Puede aumentar bastante el uso de CPU y normalmente no se recomienda.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Alto (3/4)** — Alto: puede desactivar una función importante o reducir una protección.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.

<a id="cat-diagnostico"></a>
## Diagnóstico

### Normalizar override MMCSS <10 a 20

- **Qué hace:** Corrige un valor raro de prioridades multimedia cuando está entre 0 y 9. Windows ya trata esos valores como 20, así que esto ordena la configuración pero no debería dar más rendimiento.
- **¿Funciona / merece la pena?:** Sí hace el cambio, pero **no esperes una mejora de rendimiento**: Windows ya interpreta esos valores de forma equivalente.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

<a id="cat-cpu-y-energia"></a>
## CPU y energia

### Habilitar boost de CPU en AC si estaba desactivado

- **Qué hace:** Vuelve a permitir el turbo del procesador en un sobremesa conectado a corriente si estaba desactivado.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Restaurar Power Throttling a control normal

- **Qué hace:** Devuelve a Windows y al usuario el control normal del ahorro de energía de procesos en segundo plano.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### Restaurar maximo CPU al 100 % en AC/desktop

- **Qué hace:** Quita un límite artificial del procesador y vuelve a permitir el 100 % cuando un sobremesa está conectado a corriente.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### EPP orientado a rendimiento en AC/desktop

- **Qué hace:** Hace que un sobremesa conectado a corriente favorezca más el rendimiento de CPU que el ahorro de energía. Puede aumentar consumo y temperatura.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### EPP equilibrado en AC/desktop

- **Qué hace:** Busca un punto medio entre respuesta de CPU y consumo en un sobremesa conectado a corriente.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### EPP eficiente en bateria/laptop

- **Qué hace:** Hace que un portátil con batería favorezca autonomía y temperatura frente al rendimiento máximo.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Priorizar refrigeracion activa en AC/laptop

- **Qué hace:** En un portátil enchufado, prefiere usar más los ventiladores antes que bajar el rendimiento de CPU. Puede hacer más ruido.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### EPP equilibrado en AC para portatil

- **Qué hace:** En un portátil enchufado, deja la CPU en un equilibrio entre rendimiento y consumo.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### EPP rendimiento en AC para portatil

- **Qué hace:** En un portátil enchufado, hace que la CPU favorezca más el rendimiento. Puede aumentar temperatura, consumo y ruido.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Desactivar boost de CPU en bateria

- **Qué hace:** Con batería, desactiva el turbo de CPU para gastar menos y calentarse menos. También reduce el rendimiento máximo.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio. Con batería tendrás menos rendimiento máximo de CPU.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### PCIe ASPM moderado en bateria

- **Qué hace:** Con batería, usa un ahorro moderado de energía para dispositivos PCIe. Puede añadir un poco de latencia al salir del ahorro.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### PCIe ASPM maximo en bateria

- **Qué hace:** Con batería, usa el ahorro de energía PCIe más fuerte. Ahorra más, pero puede tardar más en recuperar plena respuesta.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta. Puede empeorar la respuesta de algunos dispositivos PCIe al salir del ahorro.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-almacenamiento"></a>
## Almacenamiento

### Restaurar TRIM NTFS en SSD/NVMe

- **Qué hace:** Vuelve a activar el aviso que permite a un SSD saber qué espacio borrado puede reutilizar. Es mantenimiento normal para SSD compatibles.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### Restaurar optimizacion programada de unidades

- **Qué hace:** Vuelve a activar el mantenimiento programado de unidades de Windows. Windows decide el mantenimiento apropiado según el tipo de disco.
- **¿Funciona / merece la pena?:** Sí, cuando VSO7 detecta que tu PC está en el caso que intenta corregir. Es de las opciones más conservadoras.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Recomendado**.

### Restaurar control de Storage Sense al usuario

- **Qué hace:** Quita una orden que obligaba o bloqueaba Storage Sense y devuelve esa decisión al usuario.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Restaurar control de temporales de Storage Sense

- **Qué hace:** Devuelve al usuario el control sobre si Storage Sense limpia archivos temporales.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Permitir Storage Sense por politica

- **Qué hace:** Fuerza la regla de Windows oficial que permite Storage Sense. Es administracion de Windows, no un boost de rendimiento.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Bloquear Storage Sense por politica

- **Qué hace:** Bloquea Storage Sense mediante regla de Windows. Puede impedir limpiezas automaticas; no se recomienda como optimizacion.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

### Permitir limpieza de temporales de Storage Sense

- **Qué hace:** Permite mediante regla de Windows la limpieza de temporales no usados cuando Storage Sense se ejecuta.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Opcional**.

### Bloquear limpieza de temporales de Storage Sense

- **Qué hace:** Impide por regla de Windows que Storage Sense elimine temporales. Es una preferencia administrativa, no una optimizacion.
- **¿Funciona / merece la pena?:** Funciona como cambio de Windows, pero solo tiene sentido en casos concretos. **No lo apliques pensando que “más tweaks = más rendimiento”.**
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** No normalmente.
- **Clasificación de VSO7:** **Avanzado**.

<a id="cat-graficos-y-gpu"></a>
## Graficos y GPU

### Activar optimizaciones para juegos en ventana

- **Qué hace:** Activa la optimización moderna de Windows para juegos que funcionan en ventana o ventana sin bordes. Puede mejorar cómo se presentan algunos juegos compatibles.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Bajo (1/4)** — Bajo: es difícil que cause un problema serio.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar optimizaciones para juegos en ventana (A/B)

- **Qué hace:** Desactiva temporalmente esa optimización de juegos en ventana para poder comparar. No se presenta como mejor opción universal.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.

### Activar HAGS si el soporte esta verificado

- **Qué hace:** Activa la programación de GPU acelerada por hardware solo cuando Windows y el controlador indican que está soportada. El resultado depende de la GPU y del juego.
- **¿Funciona / merece la pena?:** Sí, hace lo que indica. Merece la pena solo si prefieres ese comportamiento o tienes ese problema concreto.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Opcional**.

### Desactivar HAGS (A/B) si el soporte esta verificado

- **Qué hace:** Desactiva la programación de GPU acelerada por hardware para comparar antes/después en un equipo compatible. No se asume que sea mejor.
- **¿Funciona / merece la pena?:** El cambio funciona, pero **no está demostrado que mejore todos los PCs**. Está para comparar antes/después.
- **Peligrosidad:** **Medio (2/4)** — Medio: puede afectar alguna función, compatibilidad, consumo o respuesta.
- **¿Se puede revertir?:** Sí. VSO7 guarda el estado anterior para poder restaurarlo.
- **¿Necesita reinicio?:** Puede depender del estado de Windows.
- **Clasificación de VSO7:** **Experimental**.
