# VSO7 Documentation / Documentación

Documentation written for users, not for developers. / Documentación escrita para usuarios, no para desarrolladores.

## Español

- [Tweaks: qué hace cada uno, si merece la pena, riesgo y reversibilidad](TWEAKS_ES.md)
- [Desinstalar apps: qué es cada aplicación y qué puedes perder](APPS_ES.md)

## English

- [Tweaks: what each one does, whether it is worth it, risk and reversibility](TWEAKS_EN.md)
- [App removal: what each app is and what you can lose](APPS_EN.md)

## Scope / Alcance

- **120 selectable tweaks** documented in Spanish and English.
- **140 removable app entries** documented in Spanish and English.
- Read-only diagnostics are deliberately excluded from the tweak guide because they do not modify the PC.
- App removal is clearly separated from reversible tweaks because it does not have the same automatic rollback guarantee.
