# VSO7 tweak guide


This documentation covers the **120 selectable tweaks** in the current VSO7 catalog. Read-only diagnostics are kept out of this guide because they are not optimizations.

The key idea is simple: **“it works” does not mean “it gives more FPS.”** Some options correct a clearly bad configuration, some only change Windows behavior, and some exist for A/B testing.

### Quick legend

- **Risk 1/4:** small change.
- **Risk 2/4:** can affect power use, compatibility or a feature.
- **Risk 3/4:** can disable something important or reduce protection.
- **Risk 4/4:** aggressive operation / difficult recovery.
- **Recommended:** VSO7 only proposes it automatically when it detects the right situation.
- **Optional:** it works, but depends on your preference.
- **Advanced:** specific use case; not a universal improvement.
- **Experimental:** only for before/after testing.

**Catalog summary:** 9 recommended, 74 optional, 28 advanced and 9 experimental tweaks.

## Index

1. [Special](#cat-special)
2. [Privacy & Suggested Content](#cat-privacy-suggested-content)
3. [AI](#cat-ai)
4. [Gaming](#cat-gaming)
5. [Start Menu & Search](#cat-start-menu-search)
6. [Other](#cat-other)
7. [Appearance](#cat-appearance)
8. [System](#cat-system)
9. [Multi-tasking](#cat-multi-tasking)
10. [Taskbar](#cat-taskbar)
11. [File Explorer](#cat-file-explorer)
12. [Windows Update](#cat-windows-update)
13. [Optional Windows Features](#cat-optional-windows-features)
14. [Power & USB](#cat-power-usb)
15. [Network](#cat-network)
16. [Diagnostics](#cat-diagnostics)
17. [CPU & Power](#cat-cpu-power)
18. [Storage](#cat-storage)
19. [Graphics & GPU](#cat-graphics-gpu)

<a id="cat-special"></a>
## Special

### Remove Gaming Apps

- **What it does:** Uninstalls the Xbox app and Game Bar components. Not recommended if you use Game Pass, Xbox captures, or Xbox social features.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection. You lose Xbox/Game Bar components. This can affect Game Pass, captures, Xbox sign-in or social features.
- **Can it be reversed?:** Not through VSO7’s normal Recovery path. If you apply it, assume manual repair or reinstall may be needed.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Remove HP Apps

- **What it does:** Uninstalls several preinstalled HP applications. This may remove support utilities or manufacturer-specific features.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection. You may lose HP battery, support, diagnostics, printer or other OEM-specific features.
- **Can it be reversed?:** Not through VSO7’s normal Recovery path. If you apply it, assume manual repair or reinstall may be needed.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Force Remove Edge

- **What it does:** Attempts to remove Edge even when Windows treats it as a component. This may break links, widgets, or features that depend on WebView/Edge.
- **Does it work / is it worth it?:** It can remove Edge, but VSO7 treats this as an aggressive operation because other Windows features may depend on Edge components.
- **Risk:** **Very high (4/4)** — Very high: it can remove an important component and be difficult to recover. It can break links, Widgets or features that rely on Microsoft web components. Recovery may require a manual reinstall.
- **Can it be reversed?:** Not through VSO7’s normal Recovery path. If you apply it, assume manual repair or reinstall may be needed.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

<a id="cat-privacy-suggested-content"></a>
## Privacy & Suggested Content

### Disable Telemetry

- **What it does:** Disables several Windows diagnostics, tracking, and advertising-personalization settings without disabling Windows Update.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Suggestions

- **What it does:** Removes recommendations, tips, and promotional suggestions that Windows shows in different parts of the interface.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Notifications

- **What it does:** Disables notifications from apps and other senders. You may miss useful alerts.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Location Services

- **What it does:** Prevents Windows and applications from using the device location until you enable it again.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness. Apps will not be able to use device location until you restore it.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Find My Device

- **What it does:** Disables the tracking used by Find My Device, so that anti-theft/location feature will no longer be available.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness. You lose Find my device.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Lockscreen Tips

- **What it does:** Removes suggestions and promotional content from the lock screen.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Edge Ads

- **What it does:** Reduces news, recommendations, and promotional content inside Microsoft Edge.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Settings365 Ads

- **What it does:** Removes Microsoft 365/Copilot banners and promotions from the Settings home page.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-ai"></a>
## AI

### Disable Copilot

- **What it does:** Disables Copilot integration in Windows. It does not uninstall third-party applications.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Recall

- **What it does:** Disables Recall so Windows does not use that AI-assisted history/snapshot feature.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Click To Do

- **What it does:** Disables Click to Do contextual analysis of text and images.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable AI Service Auto Start

- **What it does:** Prevents the AI service configured by Windows from starting automatically; some AI features may stop working.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Edge AI

- **What it does:** Disables several AI features integrated into Microsoft Edge.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Paint AI

- **What it does:** Disables Paint AI features when Windows exposes them through these policies.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Notepad AI

- **What it does:** Disables Notepad AI features when they are available.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-gaming"></a>
## Gaming

### Disable game capture/recording (legacy)

- **What it does:** Disables game capture/recording. VSO7 retains this advanced variant for functional compatibility, but recommends the per-user variant because this one also writes a machine policy.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem. You lose Xbox Game Bar capture/recording while it is applied.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Restore game recording policy to user control

- **What it does:** Removes a forced block on game recording and gives control back to the user. It does not enable captures by itself.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Disable per-user background game capture

- **What it does:** Disables background game recording for your user. This reduces capture activity, but you lose Xbox Game Bar’s “record what just happened” feature.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem. You lose Xbox Game Bar background capture.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Enable Game Mode

- **What it does:** Enables the official Game Mode preference. It does not promise higher FPS; Windows decides effective behavior based on the game, hardware and scheduler.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Recommended**.

### Disable Game Mode for A/B testing

- **What it does:** Disables Game Mode reversibly for a specific A/B comparison. It is not a universal recommendation.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.

### Allow controller to open Game Bar

- **What it does:** Enables the official preference that lets a controller button open Game Bar. This is a UX preference, not a performance tweak.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Block controller from opening Game Bar

- **What it does:** Reversibly disables opening Game Bar through the controller button. It only changes input/UX behavior.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-start-menu-search"></a>
## Start Menu & Search

### Disable Start Recommended

- **What it does:** Hides the recommended files and applications section of the Start menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Start All Apps

- **What it does:** Hides the All apps section/list of the Start menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Start Phone Link

- **What it does:** Disables Phone Link integration in the Start menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Bing

- **What it does:** Makes Start search focus on local results instead of querying Bing/Copilot.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Search History

- **What it does:** Prevents Windows Search from keeping the device search history. It does not disable Windows Search or delete your files.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Search Highlights

- **What it does:** Removes dynamic or promotional content from the Windows search box without disabling search.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-other"></a>
## Other

### Disable Settings Home

- **What it does:** Prevents Settings from using the promotional Home page as its main entry page.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Brave Bloat

- **What it does:** Disables several promotional Brave features, such as AI/crypto components, depending on the installed version.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-appearance"></a>
## Appearance

### Enable Dark Mode

- **What it does:** Enables the dark theme for Windows and compatible applications.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Transparency

- **What it does:** Reduces Windows transparency effects. This is a reversible visual change.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Animations

- **What it does:** Disables several animations so the interface feels more immediate.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem. The interface will look less animated and visually simpler.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-system"></a>
## System

### Disable Drag Tray

- **What it does:** Disables the tray that appears when dragging files to share or move them.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Revert Context Menu

- **What it does:** Uses the classic context-menu style similar to Windows 10. This is mainly an interface change.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Mouse Acceleration

- **What it does:** Disables Windows pointer acceleration for the traditional pointer path. This is a control preference; games using raw input may ignore it.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Disable Sticky Keys

- **What it does:** Prevents pressing Shift five times from opening the Sticky Keys dialog; it does not disable the keyboard.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Storage Sense

- **What it does:** Disables Storage Sense for the current user. This is a cleanup/storage preference, not an FPS optimization.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Fast Startup

- **What it does:** Makes Shut down perform a more complete shutdown instead of using partial hibernation. Startup may take slightly longer.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Bitlocker Auto Encryption

- **What it does:** Prevents Windows from automatically enabling device encryption on some PCs. It does not decrypt drives that are already encrypted.
- **Does it work / is it worth it?:** It works, but it is not a performance optimization. It prevents future automatic device encryption and therefore reduces protection if the PC is lost or stolen.
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection. It reduces protection against loss or theft by preventing automatic encryption on some PCs. It reduces a Windows security protection.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Modern Standby Networking

- **What it does:** Reduces network activity while the PC is in Modern Standby; background synchronization may be delayed while sleeping.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness. With networking disabled during Modern Standby, some sync and notifications may wait until the PC wakes.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

<a id="cat-multi-tasking"></a>
## Multi-tasking

### Disable Window Snapping

- **What it does:** Disables snapping windows to screen edges and snap zones.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Snap Assist

- **What it does:** Keeps other window features but prevents Windows from suggesting apps to complete a snap layout.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Snap Layouts

- **What it does:** Hides the snap-layout panel shown when hovering over Maximize or dragging to the top of the screen.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-taskbar"></a>
## Taskbar

### Taskbar Align Left

- **What it does:** Moves the main taskbar icons to the left.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Taskview

- **What it does:** Hides the Task View button; Win+Tab still depends on Windows configuration.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Disable Widgets

- **What it does:** Disables taskbar and lock-screen widgets by removing their related packages. Reinstalling them may be required to restore the feature.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection.
- **Can it be reversed?:** Not through VSO7’s normal Recovery path. If you apply it, assume manual repair or reinstall may be needed.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Chat

- **What it does:** Hides the Chat/Meet Now shortcut from the taskbar.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Enable End Task

- **What it does:** Adds an option to end an application from the context menu of its taskbar icon.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Enable Last Active Click

- **What it does:** Clicking a grouped taskbar button switches directly to the last active window.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-file-explorer"></a>
## File Explorer

### Show Known File Extensions

- **What it does:** Shows .exe, .txt, .jpg, and other known file extensions to make files easier to identify.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Show Hidden Folders

- **What it does:** Makes items marked as hidden visible in File Explorer.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Dupli Drive

- **What it does:** Prevents some USB drives from appearing twice in the File Explorer navigation pane.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Home

- **What it does:** Removes Home from the File Explorer navigation pane.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Gallery

- **What it does:** Removes Gallery from the File Explorer navigation pane.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide OneDrive

- **What it does:** Hides OneDrive from the File Explorer navigation pane; it does not uninstall the client or delete files.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide3d Objects

- **What it does:** Removes the 3D Objects folder from This PC.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Music

- **What it does:** Removes Music from This PC/the navigation pane, depending on the Windows version.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Add Folders To This PC

- **What it does:** Shows common folders such as Documents and Downloads in This PC again.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Include In Library

- **What it does:** Removes the “Include in library” entry from the File Explorer context menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Give Access To

- **What it does:** Removes the “Give access to” sharing entry from the File Explorer context menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Hide Share

- **What it does:** Removes the Share entry from the modern context menu.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-windows-update"></a>
## Windows Update

### Disable Update ASAP

- **What it does:** Disables the option to receive non-security updates as soon as possible; Windows Update remains enabled.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Prevent Update Auto Reboot

- **What it does:** Reduces automatic update restarts while a user is signed in.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness. It may postpone reboots Windows Update wanted to perform automatically.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Delivery Optimization

- **What it does:** Prevents Delivery Optimization from exchanging parts of updates with other PCs.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable Device Auto App Download

- **What it does:** Prevents Windows from automatically installing certain recommended applications when hardware is connected.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

<a id="cat-optional-windows-features"></a>
## Optional Windows Features

### Enable Windows Sandbox

- **What it does:** Enables the optional Windows Sandbox feature. A restart and compatible virtualization may be required.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection. It adds a Windows virtualization feature and may require a reboot.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Enable Windows Subsystem For Linux

- **What it does:** Enables WSL and Virtual Machine Platform. A restart may be required and the installed optional-feature set is changed.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection. It adds WSL and virtualization components. It may require a reboot and changes installed Windows features.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

<a id="cat-power-usb"></a>
## Power & USB

### Restore USB selective suspend

- **What it does:** Lets Windows put idle USB devices into a low-power state again. It saves power; it is not an FPS tweak.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

<a id="cat-network"></a>
## Network

### Enable RSS on a supported physical NIC

- **What it does:** Lets incoming network work be spread across several CPU cores. It can help under heavy traffic; it does not promise lower ping.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Restore physical NIC checksum offloads

- **What it does:** Lets the network adapter do part of the work of checking incoming and outgoing data instead of leaving all of it to the CPU.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Recommended**.

### Restore Large Send Offload (LSO)

- **What it does:** Lets the network adapter prepare large sends with less CPU work. It is mainly an efficiency feature, not a ping tweak.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Restore RSC on physical NICs

- **What it does:** Lets Windows group some received network traffic to reduce CPU work. It favors efficiency and throughput, not necessarily latency.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Disable RSC for a measured low-latency test

- **What it does:** Stops grouping some received traffic so you can test whether your workload gets lower latency. It can increase CPU use and is meant for before/after testing.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Restore global TCP/IP RSS

- **What it does:** Lets Windows spread incoming network work across multiple CPU cores again. It is a sensible restore when another tweak disabled it.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Restore global TCP/IP RSC

- **What it does:** Lets Windows group received traffic again to reduce CPU work. It is not a universal ping improvement.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Restore global task offload

- **What it does:** Lets Windows use supported network-adapter assistance again instead of doing everything on the CPU.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Restore TCP receive autotuning to Normal

- **What it does:** Returns network receive sizing to Windows automatic control. It removes manual limits that can reduce download or transfer speed.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Enable interrupt moderation

- **What it does:** Lets the network adapter group notifications to the CPU. This reduces CPU load but can add a small amount of latency.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Disable interrupt moderation for a low-latency test

- **What it does:** Makes the network adapter notify the CPU with less grouping to test for lower latency. It can increase CPU load significantly.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Advanced**.

### Restore Energy Efficient Ethernet

- **What it does:** Restores Ethernet power saving when the adapter supports it. It saves power; it is not a gaming improvement.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Enable supported Wake-on-Magic-Packet

- **What it does:** Allows the PC to wake from the network using a special wake signal when supported. It does not improve performance.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Restore NIC selective suspend on laptops

- **What it does:** Lets a laptop put an idle network adapter into a low-power state again. It does not improve ping.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Restore TCP ECN to Disabled

- **What it does:** Returns an advanced network-congestion feature to its normal disabled state. This is normalization, not a speed tweak.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Enable TCP ECN for A/B testing

- **What it does:** Enables an advanced network-congestion feature for testing on a compatible network. It is not recommended as a general optimization.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Experimental**.

### Restore TCP timestamps to Allowed

- **What it does:** Returns TCP timing markers to normal Windows behavior. It does not promise lower ping.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Enable supported Wake-on-Pattern

- **What it does:** Allows certain network traffic patterns to wake the PC. This is convenience/power behavior, not performance.
- **Does it work / is it worth it?:** Yes, it makes that exact change, but it is a usability/appearance preference; **it is not a promise of more performance**.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Force TCP timestamps for A/B testing

- **What it does:** Forces TCP timing markers only for before/after testing. It is not a general optimization.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Experimental**.

### Disable TCP timestamps for A/B testing

- **What it does:** Disables TCP timing markers only for before/after testing. It is not a general optimization.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Experimental**.

### Disable Energy Efficient Ethernet for A/B testing

- **What it does:** Disables Ethernet power saving to test whether latency or stability changes. It can increase power use and does not guarantee lower ping.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.

### Disable Large Send Offload for A/B testing

- **What it does:** Makes the CPU do more network-send work for comparison. It can increase CPU use and does not guarantee lower latency.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.

### Disable checksum offloads for A/B testing

- **What it does:** Makes the CPU also handle network packet checking for comparison. It can significantly increase CPU use and is normally not recommended.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **High (3/4)** — High: it can disable an important feature or reduce a protection.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.

<a id="cat-diagnostics"></a>
## Diagnostics

### Normalize clamped MMCSS override below 10 to 20

- **What it does:** Cleans up an unusual multimedia-priority value when it is between 0 and 9. Windows already treats those values as 20, so this makes the configuration clearer but should not add performance.
- **Does it work / is it worth it?:** The change works, but **do not expect a performance gain**: Windows already treats those values equivalently.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

<a id="cat-cpu-power"></a>
## CPU & Power

### Enable CPU boost on AC when it was disabled

- **What it does:** Lets a plugged-in desktop CPU use turbo/boost again when it had been disabled.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Restore normal Power Throttling control

- **What it does:** Returns normal background-process power-saving control to Windows and the user.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Restore 100% CPU maximum on AC desktop

- **What it does:** Removes an artificial CPU cap and restores 100% maximum state on a plugged-in desktop.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Performance-oriented EPP on AC desktop

- **What it does:** Makes a plugged-in desktop CPU favor performance over power saving. It can increase power use and temperature.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Balanced EPP on AC desktop

- **What it does:** Uses a middle ground between CPU responsiveness and power use on a plugged-in desktop.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Efficiency-oriented EPP on laptop battery

- **What it does:** Makes a laptop on battery favor battery life and temperature over maximum CPU performance.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Prefer active cooling on AC laptop

- **What it does:** On a plugged-in laptop, prefers using the fans more before reducing CPU performance. It may be noisier.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Balanced EPP on AC laptop

- **What it does:** On a plugged-in laptop, keeps the CPU at a balance between performance and power use.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Performance-oriented EPP on AC laptop

- **What it does:** On a plugged-in laptop, makes the CPU favor performance more strongly. It can increase temperature, power use and fan noise.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Disable CPU boost on battery

- **What it does:** On battery, disables CPU turbo/boost to reduce power use and temperature. Peak performance also drops.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem. Peak CPU performance is lower on battery.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Moderate PCIe ASPM on battery

- **What it does:** On battery, uses moderate PCIe power saving. It can add a little wake-up latency.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Maximum PCIe ASPM on battery

- **What it does:** On battery, uses stronger PCIe power saving. It saves more power but may take longer to return to full responsiveness.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness. Some PCIe devices may be slower to return from power saving.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

<a id="cat-storage"></a>
## Storage

### Restore NTFS TRIM on SSD/NVMe

- **What it does:** Restores the normal SSD notification that tells a drive which deleted space can be reused. This is normal maintenance for supported SSDs.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Restore scheduled drive optimization

- **What it does:** Restores Windows scheduled drive maintenance. Windows chooses the appropriate maintenance for each drive type.
- **Does it work / is it worth it?:** Yes, when VSO7 detects the situation it is designed to correct. It is one of the more conservative choices.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Recommended**.

### Restore Storage Sense policy to user control

- **What it does:** Removes a forced Storage Sense rule and gives the choice back to the user.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Restore Storage Sense temp-cleanup policy to user control

- **What it does:** Gives the user control over whether Storage Sense cleans temporary files.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Allow Storage Sense by policy

- **What it does:** Forces the official policy that allows Storage Sense. This is Windows administration, not a performance boost.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Block Storage Sense by policy

- **What it does:** Blocks Storage Sense through policy. It can prevent automatic cleanup and is not recommended as an optimization.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

### Allow Storage Sense temporary-file cleanup

- **What it does:** Allows the documented policy for unused temporary-file cleanup when Storage Sense runs.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Optional**.

### Block Storage Sense temporary-file cleanup

- **What it does:** Prevents Storage Sense temporary-file cleanup by policy. This is an administrative preference, not an optimization.
- **Does it work / is it worth it?:** It works as a Windows change, but only makes sense in specific cases. **Do not assume “more tweaks = more performance”.**
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** Usually no.
- **VSO7 classification:** **Advanced**.

<a id="cat-graphics-gpu"></a>
## Graphics & GPU

### Enable optimizations for windowed games

- **What it does:** Enables the modern Windows optimization for games running in windowed or borderless mode. It can improve presentation behavior for some compatible games.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Low (1/4)** — Low: it is unlikely to cause a serious problem.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Disable optimizations for windowed games (A/B)

- **What it does:** Temporarily disables that windowed-game optimization so you can compare results. It is not presented as universally better.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.

### Enable HAGS when support is verified

- **What it does:** Enables hardware-accelerated GPU scheduling only when Windows and the driver report support. Results depend on the GPU and game.
- **Does it work / is it worth it?:** Yes, it does what it says. It is worth using only if you want that behavior or have that specific problem.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Optional**.

### Disable HAGS (A/B) when support is verified

- **What it does:** Disables hardware-accelerated GPU scheduling so you can compare before/after on a supported PC. It is not assumed to be better.
- **Does it work / is it worth it?:** The setting works, but it is **not proven to improve every PC**. It is there for before/after testing.
- **Risk:** **Medium (2/4)** — Medium: it can affect a feature, compatibility, power use or responsiveness.
- **Can it be reversed?:** Yes. VSO7 records the previous state so it can be restored.
- **Reboot needed?:** It can depend on the current Windows state.
- **VSO7 classification:** **Experimental**.
