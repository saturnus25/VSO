# Guía para desinstalar aplicaciones con VSO7

Esta guía cubre las **140 aplicaciones** del selector de VSO7. “Segura” no significa “basura”: significa que Windows puede funcionar normalmente sin ella. **Si la usas, no la quites.**

> **La desinstalación de apps no tiene el mismo Recovery automático que un tweak reversible.** Muchas se pueden volver a instalar desde Microsoft Store u otro instalador, pero VSO7 no promete reconstruir exactamente el estado anterior.

- **Segura (86):** prescindible para Windows básico. VSO7 puede marcarla por defecto.
- **Opcional (48):** puede ser útil o estar relacionada con otras funciones; decide tú.
- **No recomendada (6):** otras funciones pueden depender de ella.

## Seguras / prescindibles

### Clipchamp

- **Qué es:** editor de vídeo de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### 3D Builder

- **Qué es:** herramienta antigua para modelos e impresión 3D.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Cortana

- **Qué es:** el antiguo asistente de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Finance

- **Qué es:** noticias y datos financieros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Food And Drink

- **Qué es:** recetas y contenido de comida.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Health And Fitness

- **Qué es:** contenido de salud y ejercicio.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing News

- **Qué es:** noticias.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Sports

- **Qué es:** noticias y resultados deportivos.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Translator

- **Qué es:** traducción.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Travel

- **Qué es:** información de viajes.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bing Weather

- **Qué es:** tiempo y previsión.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft Copilot

- **Qué es:** la aplicación de Copilot.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Copilot+ AI Hub

- **Qué es:** centro de funciones de IA para equipos compatibles.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft PC Manager

- **Qué es:** herramientas de mantenimiento de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Get Started

- **Qué es:** consejos y bienvenida de Windows.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Messaging

- **Qué es:** la antigua aplicación de mensajería.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### 3D Viewer

- **Qué es:** visor de modelos 3D.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft Journal

- **Qué es:** notas escritas a mano.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Office Hub

- **Qué es:** accesos y promoción de Microsoft 365.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Power BI

- **Qué es:** visualización de informes de Power BI.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Solitaire Collection

- **Qué es:** juegos de cartas de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Sticky Notes

- **Qué es:** Notas rápidas.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Mixed Reality Portal

- **Qué es:** portal de realidad mixta.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Network Speed Test

- **Qué es:** prueba de velocidad de red.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft News

- **Qué es:** noticias de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### OneNote

- **Qué es:** notas de OneNote.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Sway

- **Qué es:** presentaciones/páginas de Sway.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### One Connect

- **Qué es:** aplicación antigua de conectividad.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Print 3D

- **Qué es:** impresión 3D.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Power Automate

- **Qué es:** automatización de tareas.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Skype (UWP)

- **Qué es:** versión antigua de Skype.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft To Do

- **Qué es:** listas y tareas.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Dev Home

- **Qué es:** panel para desarrollo.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Alarms & Clock

- **Qué es:** alarmas, reloj y temporizadores.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Feedback Hub

- **Qué es:** enviar comentarios a Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Windows Maps

- **Qué es:** mapas.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Sound Recorder

- **Qué es:** grabación de sonido.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Xbox Console Companion

- **Qué es:** antigua app complementaria de Xbox.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Movies & TV

- **Qué es:** reproductor de vídeo de Microsoft.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Family Safety

- **Qué es:** controles familiares.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Quick Assist

- **Qué es:** asistencia remota.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft Teams (Old)

- **Qué es:** versión antigua de Teams.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Microsoft Teams (New)

- **Qué es:** aplicación de Teams.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### ACG Media Player

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Actipro Software

- **Qué es:** paquete/aplicación de terceros de Actipro.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Adobe Photoshop Express

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Amazon

- **Qué es:** app de compras de Amazon.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Prime Video

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Asphalt 8

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Autodesk SketchBook

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Caesars Slots

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Cooking Fever

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### CyberLink Media Suite

- **Qué es:** herramientas multimedia de CyberLink.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Disney Magic Kingdoms

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Disney+

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Drawboard PDF

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Duolingo

- **Qué es:** aprendizaje de idiomas.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Eclipse Manager

- **Qué es:** aplicación de terceros llamada Eclipse Manager.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Facebook

- **Qué es:** red social o contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### FarmVille 2

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Flipboard

- **Qué es:** red social o contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Hidden City

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Hulu

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### iHeartRadio

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Instagram

- **Qué es:** red social o contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Bubble Witch 3

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Candy Crush Saga

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Candy Crush Soda

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### LinkedIn

- **Qué es:** red social o contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### March of Empires

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Netflix

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### NYT Crossword

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### One Calendar

- **Qué es:** calendario de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Pandora

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Phototastic Collage

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### PicsArt

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Polarr Photo Editor

- **Qué es:** aplicación “Polarr Photo Editor”.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Royal Revolt

- **Qué es:** juego o entretenimiento de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Live Wallpaper

- **Qué es:** edición o creación de contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Sling TV

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### Spotify

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### TikTok

- **Qué es:** red social o contenido de terceros.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### TuneIn Radio

- **Qué es:** reproducción o streaming multimedia.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### WinZip

- **Qué es:** compresión y apertura de archivos.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** Sí.

### People

- **Qué es:** contactos.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** No.

### Mail & Calendar

- **Qué es:** antiguas apps de correo y calendario.
- **¿La quitaría?:** Sí, si no la usas. No es necesaria para el funcionamiento básico de Windows.
- **Peligro:** Bajo: pierdes principalmente esa aplicación y sus funciones.
- **VSO7 la selecciona por defecto:** No.

## Opcionales: decide tú

### Bing Search

- **Qué es:** resultados web de Bing integrados en Windows.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Xbox Gaming App

- **Qué es:** Xbox y Game Pass para PC.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes la app Xbox y acceso cómodo a Game Pass para PC.

### Microsoft 365 Companions

- **Qué es:** pequeñas apps ligadas a Microsoft 365.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Paint 3D

- **Qué es:** editor 3D de Microsoft.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### OneDrive

- **Qué es:** sincronización de archivos con OneDrive.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Comprueba antes si Escritorio, Documentos o Fotos están sincronizados: la sincronización se detendrá.

### Outlook for Windows

- **Qué es:** correo y calendario de Outlook.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Paint

- **Qué es:** editor básico de imágenes/dibujo.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Necesitarás otra app para dibujo/edición básica.

### Remote Desktop

- **Qué es:** cliente de Escritorio remoto.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes ese cliente de conexión remota.

### Snipping Tool

- **Qué es:** capturas y grabación de pantalla.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes la herramienta integrada de capturas y grabación de pantalla.

### Widgets Experience

- **Qué es:** experiencia de Widgets.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Whiteboard

- **Qué es:** pizarra colaborativa.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Photos

- **Qué es:** visor y editor de fotos.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Necesitarás otro visor de imágenes.

### Calculator

- **Qué es:** calculadora.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Necesitarás otra calculadora.

### Camera

- **Qué es:** cámara/webcam.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes la aplicación integrada de cámara.

### Notepad

- **Qué es:** editor de texto simple.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Necesitarás otro editor de texto.

### Xbox Game Overlay

- **Qué es:** parte de la superposición Xbox en juegos.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puedes perder partes de Game Bar.

### Xbox Gaming Overlay

- **Qué es:** Xbox Game Bar.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puedes perder Game Bar, capturas y widgets Xbox.

### Phone Link

- **Qué es:** conexión del PC con el móvil.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes la integración con el móvil.

### Media Player

- **Qué es:** reproductor multimedia.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Necesitarás otro reproductor multimedia.

### Cross Device Experience

- **Qué es:** funciones entre varios dispositivos.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Windows Web Experience Pack

- **Qué es:** componentes web usados por Widgets y otras partes de Windows.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puede afectar Widgets y otras partes de Windows.

### Widgets Platform Runtime

- **Qué es:** motor necesario para Widgets.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Los Widgets pueden dejar de funcionar.

### LG Monitor App

- **Qué es:** utilidades para monitores LG.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP AI Experience Center

- **Qué es:** funciones de IA de HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Connected Music

- **Qué es:** antigua app multimedia de HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Connected Photo

- **Qué es:** antigua app de fotos de HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Desktop Support Utilities

- **Qué es:** utilidades de soporte HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Easy Clean

- **Qué es:** bloqueo temporal de entrada para poder limpiar el equipo.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP File Viewer

- **Qué es:** visor de archivos HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP JumpStarts

- **Qué es:** bienvenida/promociones de HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP PC Hardware Diagnostics

- **Qué es:** diagnóstico de hardware HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Power Manager

- **Qué es:** controles de batería/energía HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puedes perder controles específicos de batería/carga HP.

### HP Printer Control

- **Qué es:** controles de impresora HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Si usas impresora HP, puedes perder controles de esa app.

### HP Privacy Settings

- **Qué es:** ajustes de privacidad HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP QuickDrop

- **Qué es:** transferencia rápida de archivos HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP QuickTouch

- **Qué es:** funciones rápidas de algunos equipos HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Registration

- **Qué es:** registro del equipo con HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Support Assistant

- **Qué es:** soporte, diagnóstico y actualizaciones HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes el flujo de soporte/actualizaciones de HP; Windows Update sigue funcionando.

### HP Sure Shield AI

- **Qué es:** funciones de seguridad HP compatibles.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP System Information

- **Qué es:** información del sistema HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP Welcome

- **Qué es:** pantalla de bienvenida HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### HP WorkWell

- **Qué es:** herramientas de bienestar HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### myHP

- **Qué es:** panel de funciones y soporte HP.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Lenovo Vantage

- **Qué es:** ajustes, batería, firmware y soporte Lenovo.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puedes perder controles de batería, carga, modos térmicos o actualizaciones de Lenovo.

### Lenovo Vantage Service

- **Qué es:** servicio necesario para varias funciones de Lenovo Vantage.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Lenovo Vantage puede dejar de funcionar correctamente.

### Dell SupportAssist

- **Qué es:** soporte, diagnóstico y actualizaciones Dell.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes el soporte/diagnóstico/actualizador de Dell; Windows Update sigue funcionando.

### Dell Digital Delivery Services

- **Qué es:** descarga de software incluido/comprado con Dell.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

### Dell Mobile Connect

- **Qué es:** conexión móvil-PC de Dell.
- **¿La quitaría?:** Solo si sabes que no la necesitas. VSO7 no la selecciona automáticamente.
- **Peligro:** Medio: puedes perder una función de Windows o del fabricante que sí uses.
- **VSO7 la selecciona por defecto:** No.

## No recomendadas para desinstalar

### Get Help

- **Qué es:** soporte y ayuda de Windows.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Pierdes la aplicación integrada de soporte.

### Microsoft Store

- **Qué es:** tienda y actualización de aplicaciones.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puede complicar bastante instalar y actualizar aplicaciones de Microsoft.

### Windows Terminal

- **Qué es:** terminal moderna de Windows.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puedes perder la terminal moderna usada por PowerShell, CMD y herramientas de desarrollo.

### Xbox TCUI Framework

- **Qué es:** parte del inicio de sesión e interfaz de Xbox usada por juegos.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Algunos juegos pueden perder diálogos o funciones Xbox.

### Xbox Identity Provider

- **Qué es:** inicio de sesión e identidad Xbox.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puede romper inicio de sesión Xbox, Game Pass y juegos que usan esa identidad.

### Xbox Speech To Text

- **Qué es:** funciones de voz/texto de Xbox.
- **¿La quitaría?:** Yo no la quitaría salvo que sepas exactamente qué depende de ella.
- **Peligro:** Alto: puede romper otras funciones o aplicaciones.
- **VSO7 la selecciona por defecto:** No.
- **Ojo:** Puede romper funciones de voz/accesibilidad Xbox.
